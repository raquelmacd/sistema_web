<?php
  //verificar se não está logado
  if ( !isset ( $_SESSION["hqs"]["id"] ) ){
    exit;
  }
  //iniciar as variaveis
  $titulo = $tipo = $editora = $valor = $capa = $numero = $resumo = $data ="";

  //se nao existe o id
  if ( !isset ( $id ) ) $id = "";
    if ( !empty ( $id ) ) {
  	//selecionar os dados do banco
  	$sql = "select * from quadrinho 
  		where id = :id limit 1";
  	$consulta = $pdo->prepare($sql);
  	$consulta->bindParam(':id', $id); 
  	//$id - linha 255 do index.php
  	$consulta->execute();
  	$dados  = $consulta->fetch(PDO::FETCH_OBJ);

  	//separar os dados
  	$id 	= $dados->id;
  	$titulo = $dados->titulo;
    $data   = $dados->data;
    $valor  = $dados->valor;
    $numero = $dados->numero;
    $tipo   = $dados->tipo_id;
    $editora = $dados->editora_id;
    $resumo  = $dados->resumo;
    $capa    = $dados->capa;
    $valor = number_format($valor,2,",",".");
  } 
  ?>
  <div class="container">
	<h1 class="float-left">Cadastro de Quadrinho</h1>
	<div class="float-right">
		<a href="cadastro/quadrinho" class="btn btn-success">Novo Registro</a>
		<a href="listar/quadrinho" class="btn btn-info">Listar Registros</a>
	</div>
	<div class="clearfix"></div>

	<form name="formCadastro" method="post" action="salvar/quadrinho" data-parsley-validate enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-6">            
                <label for="id">ID</label>
                <input type="text" name="id" id="id"class="form-control" readonly value="<?=$id;?>">
				<label for="tipo_id">Tipo de Quadrinho</label>
				<select name="tipo_id" id="tipo_id" class="form-control" required data-parsley-required-message="Selecione uma opção" >
					<option value="" ></option>
					<?php
					$sql = "select id, tipo from tipo order by tipo";
					$consulta = $pdo->prepare($sql);
					$consulta->execute();

					while ($d = $consulta->fetch(PDO::FETCH_OBJ)) {
						$id = $d->id;
						$tipo = $d->tipo;

						echo "<option value='{$id}'>{$tipo}</option>";
					}

					?>
				</select>
			</div>
			<div class="col-md-6">

                <label for="titulo">Titulo do Quadrinho</label>
                <input type="text" name="titulo" id="titulo" class="form-control" required	data-parsley-required-message="Preencha este campo, por favor"	value="<?=$titulo;?>">
                
				<label for="editora_id">Editora do Quadrinho</label>
				<select name="editora_id" id="editora_id" class="form-control" required data-parsley-required-message="Selecione uma opção">
					<option value="" ></option>
					<?php
					$sql = "select id, nome from editora order by nome";
					$consulta = $pdo->prepare($sql);
					$consulta->execute();

					while ($d = $consulta->fetch(PDO::FETCH_OBJ)) {
						$id = $d->id;
						$editora = $d->nome;

						echo "<option value='{$id}'>{$editora}</option>";
					}

					?>
				</select>
			</div>	

			<div class="col-md-6">

				<label for="valor">Valor</label>
				<input type="text" name="valor" class="form-control" id="valor" value="<?=$valor;?>">
                
                <label for="numero">Número</label>
				<input type="text" name="numero" class="form-control" id="numero" value="<?=$numero;?>">

				<label for="data">Data de lançamento</label>
				<input type="text" name="data" class="form-control" id="data" value="<?=$data;?>">
			</div>
			<div class="col-md-6">
				<label for="capa">Capa do Quadrinho</label>
				<input type="file" name="capa" id="capa" class="form-control" accept=".jpg">
                <?php  
                     $foto = "<img src='../fotos/".$capa."p.jpg' alt='".$titulo."' width='150px'>";
                if(empty($capa)){
                    $foto = "";
                }       ?>
                <div><?php echo $foto ;?></div>
				<label for="resumo">Resumo</label>
				<textarea class="form-control" rows="8" id="resumo" name="resumo"  value="<?=$resumo;?>"></textarea>
			</div>
		</div>


		<button type="submit" class="btn btn-success margin">
			<i class="fas fa-check"></i> Gravar Dados
		</button>

	</form>

	<div class="clearfix"></div>
</div>
<script>
    $(document).ready(function() {
      $('#resumo').summernote();
      $('#valor').maskMoney({
          thousands: ".",
          decimal: ","
      });
        $("#data").inputmask("99/99/9999");
        $("#numero").inputmask("9999");
    });
</script>