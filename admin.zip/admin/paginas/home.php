<div class="container">
    <h1 class="float-left">Dashboard</h1>
</div>